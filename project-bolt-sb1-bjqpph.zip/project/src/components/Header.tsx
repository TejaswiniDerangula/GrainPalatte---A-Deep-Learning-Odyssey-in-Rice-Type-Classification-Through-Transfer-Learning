import React from 'react';
import { Brain, Brain as Grain } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="gradient-bg text-white py-8 shadow-2xl">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center space-x-4 mb-4">
          <div className="bg-white/20 p-3 rounded-full">
            <Grain className="h-8 w-8" />
          </div>
          <div className="bg-white/20 p-3 rounded-full">
            <Brain className="h-8 w-8" />
          </div>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-4">
          GrainPalette
        </h1>
        <p className="text-xl text-center text-green-100 max-w-3xl mx-auto">
          A Deep Learning Odyssey In Rice Type Classification Through Transfer Learning
        </p>
      </div>
    </header>
  );
};

export default Header;