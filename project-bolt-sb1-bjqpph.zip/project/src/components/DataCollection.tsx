import React, { useState } from 'react';
import { Database, Download, Camera, FileImage, BarChart3 } from 'lucide-react';

const DataCollection: React.FC = () => {
  const [uploadedImages, setUploadedImages] = useState<number>(0);

  const riceTypes = [
    { name: 'Basmati', samples: 1250, color: 'bg-green-100 text-green-800' },
    { name: 'Jasmine', samples: 1180, color: 'bg-blue-100 text-blue-800' },
    { name: 'Arborio', samples: 980, color: 'bg-purple-100 text-purple-800' },
    { name: 'Brown Rice', samples: 1350, color: 'bg-yellow-100 text-yellow-800' },
    { name: 'Wild Rice', samples: 750, color: 'bg-red-100 text-red-800' },
  ];

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      setUploadedImages(files.length);
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">1: Data Collection</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          The foundation of our rice classification model begins with comprehensive data collection. 
          We need diverse, high-quality images of different rice grain types to train our model effectively.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="section-card border-l-green-500">
          <div className="flex items-center space-x-3 mb-6">
            <Database className="h-6 w-6 text-green-500" />
            <h3 className="text-xl font-semibold text-gray-800">Dataset Overview</h3>
          </div>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-green-600">5,510</div>
                <div className="text-sm text-gray-600">Total Images</div>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-blue-600">5</div>
                <div className="text-sm text-gray-600">Rice Types</div>
              </div>
            </div>
            <div className="space-y-2">
              {riceTypes.map((rice, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${rice.color}`}>
                    {rice.name}
                  </span>
                  <span className="text-gray-600 font-semibold">{rice.samples} images</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="section-card border-l-blue-500">
          <div className="flex items-center space-x-3 mb-6">
            <Camera className="h-6 w-6 text-blue-500" />
            <h3 className="text-xl font-semibold text-gray-800">Data Collection Methods</h3>
          </div>
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-blue-800 mb-2">Photography Guidelines</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• High-resolution images (minimum 224x224px)</li>
                <li>• Consistent lighting conditions</li>
                <li>• Multiple angles per grain type</li>
                <li>• Clean background (white/neutral)</li>
              </ul>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-semibold text-green-800 mb-2">Data Sources</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Agricultural research datasets</li>
                <li>• Custom photography sessions</li>
                <li>• Public grain image repositories</li>
                <li>• Laboratory sample imaging</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="section-card border-l-orange-500">
        <div className="flex items-center space-x-3 mb-6">
          <FileImage className="h-6 w-6 text-orange-500" />
          <h3 className="text-xl font-semibold text-gray-800">Upload Sample Images</h3>
        </div>
        <div className="space-y-4">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-orange-400 transition-colors">
            <FileImage className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-4">Upload rice grain images for classification</p>
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
              id="file-upload"
            />
            <label
              htmlFor="file-upload"
              className="bg-orange-500 text-white px-6 py-2 rounded-lg cursor-pointer hover:bg-orange-600 transition-colors"
            >
              Choose Images
            </label>
            {uploadedImages > 0 && (
              <p className="mt-4 text-green-600 font-semibold">
                {uploadedImages} image(s) uploaded successfully!
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="section-card border-l-purple-500">
        <div className="flex items-center space-x-3 mb-6">
          <BarChart3 className="h-6 w-6 text-purple-500" />
          <h3 className="text-xl font-semibold text-gray-800">Data Quality Metrics</h3>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">95%</div>
            <div className="text-sm text-gray-600">Image Quality</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">88%</div>
            <div className="text-sm text-gray-600">Label Accuracy</div>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">100%</div>
            <div className="text-sm text-gray-600">Data Completeness</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataCollection;