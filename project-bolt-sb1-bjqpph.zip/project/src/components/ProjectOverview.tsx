import React from 'react';
import { CheckCircle, Target, BookOpen, Workflow, FolderTree } from 'lucide-react';

const ProjectOverview: React.FC = () => {
  const prerequisites = [
    'Basic understanding of Machine Learning concepts',
    'Knowledge of Python programming',
    'Familiarity with TensorFlow/Keras',
    'Understanding of image processing',
    'Basic knowledge of transfer learning'
  ];

  const objectives = [
    'Classify different types of rice grains using deep learning',
    'Implement transfer learning for efficient model training',
    'Build a user-friendly application for rice classification',
    'Achieve high accuracy in grain type prediction',
    'Demonstrate practical ML application in agriculture'
  ];

  const projectFlow = [
    'Data Collection and Preparation',
    'Image Preprocessing and Augmentation',
    'Model Architecture Design',
    'Transfer Learning Implementation',
    'Model Training and Validation',
    'Application Development',
    'Testing and Deployment'
  ];

  return (
    <div className="space-y-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">Project Overview</h2>
        <p className="text-lg text-gray-600 max-w-4xl mx-auto">
          This project demonstrates a comprehensive approach to building an intelligent rice grain classification 
          system using deep learning and transfer learning techniques. We'll walk through each step from data 
          collection to deployment.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="section-card border-l-orange-500">
          <div className="flex items-center space-x-3 mb-4">
            <BookOpen className="h-6 w-6 text-orange-500" />
            <h3 className="text-xl font-semibold text-gray-800">Prerequisites</h3>
          </div>
          <ul className="space-y-2">
            {prerequisites.map((item, index) => (
              <li key={index} className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500 mt-1 flex-shrink-0" />
                <span className="text-gray-600 text-sm">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="section-card border-l-green-500">
          <div className="flex items-center space-x-3 mb-4">
            <Target className="h-6 w-6 text-green-500" />
            <h3 className="text-xl font-semibold text-gray-800">Project Objectives</h3>
          </div>
          <ul className="space-y-2">
            {objectives.map((item, index) => (
              <li key={index} className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500 mt-1 flex-shrink-0" />
                <span className="text-gray-600 text-sm">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="section-card border-l-blue-500">
          <div className="flex items-center space-x-3 mb-4">
            <Workflow className="h-6 w-6 text-blue-500" />
            <h3 className="text-xl font-semibold text-gray-800">Project Flow</h3>
          </div>
          <ul className="space-y-2">
            {projectFlow.map((item, index) => (
              <li key={index} className="flex items-start space-x-2">
                <div className="bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold mt-0.5 flex-shrink-0">
                  {index + 1}
                </div>
                <span className="text-gray-600 text-sm">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="section-card border-l-purple-500">
        <div className="flex items-center space-x-3 mb-6">
          <FolderTree className="h-6 w-6 text-purple-500" />
          <h3 className="text-xl font-semibold text-gray-800">Project Structure</h3>
        </div>
        <div className="bg-gray-50 rounded-lg p-4 font-mono text-sm">
          <div className="space-y-1">
            <div>📁 GrainPalette/</div>
            <div className="ml-4">📁 data/</div>
            <div className="ml-8">📁 raw/</div>
            <div className="ml-8">📁 processed/</div>
            <div className="ml-4">📁 models/</div>
            <div className="ml-8">📄 transfer_model.h5</div>
            <div className="ml-4">📁 src/</div>
            <div className="ml-8">📄 data_collection.py</div>
            <div className="ml-8">📄 preprocessing.py</div>
            <div className="ml-8">📄 model_building.py</div>
            <div className="ml-8">📄 application.py</div>
            <div className="ml-4">📁 notebooks/</div>
            <div className="ml-8">📄 exploration.ipynb</div>
            <div className="ml-4">📄 requirements.txt</div>
            <div className="ml-4">📄 README.md</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectOverview;