import React, { useState } from 'react';
import { ImageIcon, Settings, Zap, Eye } from 'lucide-react';

const ImagePreprocessing: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string>('original');
  
  const preprocessingSteps = [
    {
      name: 'Resize & Normalize',
      description: 'Resize images to 224x224px and normalize pixel values',
      before: 'Various sizes (512x384, 800x600, etc.)',
      after: '224x224px, values [0,1]'
    },
    {
      name: 'Data Augmentation',
      description: 'Apply rotation, flipping, and brightness adjustments',
      before: 'Single orientation',
      after: 'Multiple variations per image'
    },
    {
      name: 'Background Removal',
      description: 'Remove background noise and focus on grain features',
      before: 'Complex backgrounds',
      after: 'Clean, focused grain images'
    },
    {
      name: 'Color Enhancement',
      description: 'Enhance contrast and adjust color balance',
      before: 'Varying lighting conditions',
      after: 'Consistent, enhanced colors'
    }
  ];

  const augmentationTechniques = [
    { name: 'Rotation', range: '0° to 360°', impact: 'Improves orientation invariance' },
    { name: 'Horizontal Flip', range: 'Binary', impact: 'Doubles dataset size' },
    { name: 'Brightness', range: '±20%', impact: 'Handles lighting variations' },
    { name: 'Zoom', range: '90% to 110%', impact: 'Scale invariance' },
    { name: 'Gaussian Noise', range: 'σ = 0.01', impact: 'Improves robustness' }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">2: Image Preprocessing</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Transform raw images into standardized, high-quality data suitable for deep learning. 
          This critical step ensures consistent input format and improves model performance.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="section-card border-l-blue-500">
          <div className="flex items-center space-x-3 mb-6">
            <Settings className="h-6 w-6 text-blue-500" />
            <h3 className="text-xl font-semibold text-gray-800">Preprocessing Pipeline</h3>
          </div>
          <div className="space-y-4">
            {preprocessingSteps.map((step, index) => (
              <div key={index} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">
                    {index + 1}
                  </div>
                  <h4 className="font-semibold text-gray-800">{step.name}</h4>
                </div>
                <p className="text-sm text-gray-600 mb-3">{step.description}</p>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-red-50 p-2 rounded">
                    <span className="text-red-700 font-semibold">Before: </span>
                    <span className="text-gray-600">{step.before}</span>
                  </div>
                  <div className="bg-green-50 p-2 rounded">
                    <span className="text-green-700 font-semibold">After: </span>
                    <span className="text-gray-600">{step.after}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="section-card border-l-orange-500">
          <div className="flex items-center space-x-3 mb-6">
            <Zap className="h-6 w-6 text-orange-500" />
            <h3 className="text-xl font-semibold text-gray-800">Data Augmentation</h3>
          </div>
          <div className="space-y-4">
            <div className="bg-orange-50 p-4 rounded-lg mb-4">
              <h4 className="font-semibold text-orange-800 mb-2">Why Augmentation?</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Increases dataset size from 5,510 to ~27,550 images</li>
                <li>• Improves model generalization</li>
                <li>• Reduces overfitting</li>
                <li>• Handles real-world variations</li>
              </ul>
            </div>
            <div className="space-y-3">
              {augmentationTechniques.map((technique, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-semibold text-gray-800">{technique.name}</div>
                    <div className="text-xs text-gray-500">{technique.impact}</div>
                  </div>
                  <div className="text-sm text-orange-600 font-medium">
                    {technique.range}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="section-card border-l-green-500">
        <div className="flex items-center space-x-3 mb-6">
          <Eye className="h-6 w-6 text-green-500" />
          <h3 className="text-xl font-semibold text-gray-800">Image Transformation Visualization</h3>
        </div>
        <div className="space-y-4">
          <div className="flex space-x-2 mb-4">
            {['original', 'resized', 'augmented', 'enhanced'].map((type) => (
              <button
                key={type}
                onClick={() => setSelectedImage(type)}
                className={`px-4 py-2 rounded-lg capitalize transition-colors ${
                  selectedImage === type
                    ? 'bg-green-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-gray-100 aspect-square rounded-lg flex items-center justify-center">
              <div className="text-center">
                <ImageIcon className="h-16 w-16 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500 capitalize">{selectedImage} Image</p>
                <p className="text-xs text-gray-400 mt-1">
                  {selectedImage === 'original' && 'Raw input image'}
                  {selectedImage === 'resized' && '224x224px normalized'}
                  {selectedImage === 'augmented' && 'With rotations & flips'}
                  {selectedImage === 'enhanced' && 'Color corrected'}
                </p>
              </div>
            </div>
            <div className="col-span-2 space-y-3">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold text-blue-800 mb-2">Processing Parameters</h4>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>Target Size: <span className="font-mono">224×224</span></div>
                  <div>Color Mode: <span className="font-mono">RGB</span></div>
                  <div>Normalization: <span className="font-mono">[0, 1]</span></div>
                  <div>Batch Size: <span className="font-mono">32</span></div>
                </div>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Quality Metrics</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Image Clarity</span>
                    <div className="bg-green-200 rounded-full h-2 w-20">
                      <div className="bg-green-500 h-2 rounded-full w-4/5"></div>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Consistency</span>
                    <div className="bg-green-200 rounded-full h-2 w-20">
                      <div className="bg-green-500 h-2 rounded-full w-5/6"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="section-card border-l-purple-500">
        <div className="flex items-center space-x-3 mb-6">
          <ImageIcon className="h-6 w-6 text-purple-500" />
          <h3 className="text-xl font-semibold text-gray-800">Implementation Code</h3>
        </div>
        <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
          <pre>{`# Image Preprocessing Pipeline
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# Data Augmentation
datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=40,
    width_shift_range=0.2,
    height_shift_range=0.2,
    horizontal_flip=True,
    zoom_range=0.2,
    brightness_range=[0.8, 1.2]
)

# Load and preprocess images
def preprocess_image(image_path):
    image = tf.io.read_file(image_path)
    image = tf.image.decode_image(image, channels=3)
    image = tf.image.resize(image, [224, 224])
    image = tf.cast(image, tf.float32) / 255.0
    return image`}</pre>
        </div>
      </div>
    </div>
  );
};

export default ImagePreprocessing;