import React, { useState } from 'react';
import { Brain, Layers, TrendingUp, Save } from 'lucide-react';

const ModelBuilding: React.FC = () => {
  const [selectedModel, setSelectedModel] = useState('mobilenet');
  
  const baseModels = [
    {
      id: 'mobilenet',
      name: 'MobileNetV2',
      params: '3.5M',
      accuracy: '94.2%',
      speed: 'Fast',
      description: 'Lightweight model optimized for mobile devices'
    },
    {
      id: 'resnet',
      name: 'ResNet50',
      params: '25.6M',
      accuracy: '96.1%',
      speed: 'Medium',
      description: 'Deep residual network with skip connections'
    },
    {
      id: 'efficientnet',
      name: 'EfficientNetB0',
      params: '5.3M',
      accuracy: '95.8%',
      speed: 'Medium',
      description: 'Optimized for efficiency and accuracy'
    }
  ];

  const trainingMetrics = [
    { epoch: 1, trainAcc: 0.65, valAcc: 0.62, trainLoss: 1.24, valLoss: 1.31 },
    { epoch: 5, trainAcc: 0.82, valAcc: 0.79, trainLoss: 0.68, valLoss: 0.72 },
    { epoch: 10, trainAcc: 0.91, valAcc: 0.88, trainLoss: 0.35, valLoss: 0.41 },
    { epoch: 15, trainAcc: 0.95, valAcc: 0.92, trainLoss: 0.21, valLoss: 0.28 },
    { epoch: 20, trainAcc: 0.97, valAcc: 0.94, trainLoss: 0.15, valLoss: 0.23 }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">3: Model Building</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Build and train a deep learning model using transfer learning. We'll leverage pre-trained models 
          and fine-tune them for rice grain classification to achieve high accuracy with efficient training.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="section-card border-l-blue-500">
          <div className="flex items-center space-x-3 mb-6">
            <Brain className="h-6 w-6 text-blue-500" />
            <h3 className="text-xl font-semibold text-gray-800">Transfer Learning Models</h3>
          </div>
          <div className="space-y-4">
            {baseModels.map((model) => (
              <div
                key={model.id}
                onClick={() => setSelectedModel(model.id)}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  selectedModel === model.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-blue-300'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-gray-800">{model.name}</h4>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    selectedModel === model.id ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {model.accuracy}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mb-3">{model.description}</p>
                <div className="flex justify-between text-xs text-gray-500">
                  <span>Parameters: {model.params}</span>
                  <span>Speed: {model.speed}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="section-card border-l-green-500">
          <div className="flex items-center space-x-3 mb-6">
            <Layers className="h-6 w-6 text-green-500" />
            <h3 className="text-xl font-semibold text-gray-800">Model Architecture</h3>
          </div>
          <div className="space-y-4">
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold text-green-800 mb-3">Transfer Learning Approach</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm">Pre-trained {baseModels.find(m => m.id === selectedModel)?.name} backbone</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <span className="text-sm">Frozen convolutional layers</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                  <span className="text-sm">Custom classification head</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                  <span className="text-sm">5-class softmax output</span>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-800 mb-3">Custom Layers</h4>
              <div className="space-y-2 text-sm font-mono">
                <div className="bg-white p-2 rounded">GlobalAveragePooling2D</div>
                <div className="bg-white p-2 rounded">Dense(128, activation='relu')</div>
                <div className="bg-white p-2 rounded">Dropout(0.3)</div>
                <div className="bg-white p-2 rounded">Dense(5, activation='softmax')</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="section-card border-l-orange-500">
        <div className="flex items-center space-x-3 mb-6">
          <TrendingUp className="h-6 w-6 text-orange-500" />
          <h3 className="text-xl font-semibold text-gray-800">Training Progress</h3>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold text-gray-800 mb-3">Training Metrics</h4>
            <div className="space-y-2">
              {trainingMetrics.map((metric, index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm font-medium">Epoch {metric.epoch}</span>
                  <div className="flex space-x-4 text-xs">
                    <span className="text-green-600">Val Acc: {(metric.valAcc * 100).toFixed(1)}%</span>
                    <span className="text-blue-600">Loss: {metric.valLoss.toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h4 className="font-semibold text-gray-800 mb-3">Training Configuration</h4>
            <div className="bg-orange-50 p-4 rounded-lg space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Optimizer:</span>
                <span className="font-mono">Adam</span>
              </div>
              <div className="flex justify-between">
                <span>Learning Rate:</span>
                <span className="font-mono">0.001</span>
              </div>
              <div className="flex justify-between">
                <span>Batch Size:</span>
                <span className="font-mono">32</span>
              </div>
              <div className="flex justify-between">
                <span>Epochs:</span>
                <span className="font-mono">20</span>
              </div>
              <div className="flex justify-between">
                <span>Early Stopping:</span>
                <span className="font-mono">Patience: 5</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="section-card border-l-purple-500">
        <div className="flex items-center space-x-3 mb-6">
          <Save className="h-6 w-6 text-purple-500" />
          <h3 className="text-xl font-semibold text-gray-800">Model Implementation</h3>
        </div>
        <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
          <pre>{`# Transfer Learning Model Implementation
import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense, Dropout
from tensorflow.keras.models import Model

# Load pre-trained model
base_model = MobileNetV2(
    weights='imagenet',
    include_top=False,
    input_shape=(224, 224, 3)
)

# Freeze base model layers
base_model.trainable = False

# Add custom classification head
inputs = tf.keras.Input(shape=(224, 224, 3))
x = base_model(inputs, training=False)
x = GlobalAveragePooling2D()(x)
x = Dropout(0.3)(x)
predictions = Dense(5, activation='softmax')(x)

model = Model(inputs, predictions)

# Compile model
model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

# Train model
history = model.fit(
    train_dataset,
    epochs=20,
    validation_data=val_dataset,
    callbacks=[early_stopping]
)`}</pre>
        </div>
      </div>

      <div className="section-card border-l-green-500">
        <div className="flex items-center space-x-3 mb-6">
          <TrendingUp className="h-6 w-6 text-green-500" />
          <h3 className="text-xl font-semibold text-gray-800">Model Performance</h3>
        </div>
        <div className="grid md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">94.2%</div>
            <div className="text-sm text-gray-600">Validation Accuracy</div>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">0.23</div>
            <div className="text-sm text-gray-600">Final Loss</div>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">15min</div>
            <div className="text-sm text-gray-600">Training Time</div>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <div className="text-2xl font-bold text-orange-600">12MB</div>
            <div className="text-sm text-gray-600">Model Size</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModelBuilding;