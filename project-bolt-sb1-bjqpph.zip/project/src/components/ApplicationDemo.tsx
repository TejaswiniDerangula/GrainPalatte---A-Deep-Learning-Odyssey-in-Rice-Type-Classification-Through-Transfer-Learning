import React, { useState, useRef } from 'react';
import { Camera, Upload, Brain, CheckCircle, AlertCircle } from 'lucide-react';

const ApplicationDemo: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [prediction, setPrediction] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const riceTypes = [
    { name: 'Basmati', characteristics: 'Long grain, aromatic, fluffy texture' },
    { name: 'Jasmine', characteristics: 'Long grain, fragrant, slightly sticky' },
    { name: 'Arborio', characteristics: 'Short grain, high starch, creamy texture' },
    { name: 'Brown Rice', characteristics: 'Whole grain, nutty flavor, chewy texture' },
    { name: 'Wild Rice', characteristics: 'Dark grain, earthy flavor, firm texture' }
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      setPrediction(null);
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage) return;
    
    setIsAnalyzing(true);
    
    // Simulate AI analysis with random prediction
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockPredictions = [
      { type: 'Basmati', confidence: 0.89 },
      { type: 'Jasmine', confidence: 0.92 },
      { type: 'Arborio', confidence: 0.76 },
      { type: 'Brown Rice', confidence: 0.84 },
      { type: 'Wild Rice', confidence: 0.71 }
    ];
    
    const randomPrediction = mockPredictions[Math.floor(Math.random() * mockPredictions.length)];
    setPrediction(randomPrediction);
    setIsAnalyzing(false);
  };

  return (
    <div className="space-y-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">5: Application Demo</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Experience the power of our trained model! Upload an image of rice grains and get 
          instant classification results with confidence scores and detailed information.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="section-card border-l-blue-500">
          <div className="flex items-center space-x-3 mb-6">
            <Upload className="h-6 w-6 text-blue-500" />
            <h3 className="text-xl font-semibold text-gray-800">Upload Rice Image</h3>
          </div>
          <div className="space-y-4">
            <div 
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              {selectedImage ? (
                <div className="space-y-4">
                  <img 
                    src={URL.createObjectURL(selectedImage)} 
                    alt="Selected rice" 
                    className="max-w-full max-h-48 mx-auto rounded-lg"
                  />
                  <p className="text-green-600 font-semibold">{selectedImage.name}</p>
                </div>
              ) : (
                <>
                  <Camera className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">Click to upload rice grain image</p>
                  <p className="text-sm text-gray-500">Supports JPG, PNG, WebP (max 5MB)</p>
                </>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            
            {selectedImage && (
              <button
                onClick={analyzeImage}
                disabled={isAnalyzing}
                className="w-full bg-blue-500 text-white py-3 rounded-lg font-semibold hover:bg-blue-600 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                <Brain className="h-5 w-5" />
                <span>{isAnalyzing ? 'Analyzing...' : 'Analyze Image'}</span>
              </button>
            )}
          </div>
        </div>

        <div className="section-card border-l-green-500">
          <div className="flex items-center space-x-3 mb-6">
            <Brain className="h-6 w-6 text-green-500" />
            <h3 className="text-xl font-semibold text-gray-800">Classification Results</h3>
          </div>
          <div className="space-y-4">
            {isAnalyzing ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-green-500 mx-auto mb-4"></div>
                <p className="text-gray-600">Analyzing image with AI model...</p>
              </div>
            ) : prediction ? (
              <div className="space-y-4">
                <div className="bg-green-50 p-6 rounded-lg border-l-4 border-green-500">
                  <div className="flex items-center space-x-2 mb-2">
                    <CheckCircle className="h-6 w-6 text-green-500" />
                    <h4 className="text-xl font-bold text-green-800">{prediction.type}</h4>
                  </div>
                  <p className="text-green-700 mb-3">
                    Confidence: {(prediction.confidence * 100).toFixed(1)}%
                  </p>
                  <p className="text-gray-600 text-sm">
                    {riceTypes.find(r => r.name === prediction.type)?.characteristics}
                  </p>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h5 className="font-semibold text-gray-800 mb-3">Confidence Breakdown</h5>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div 
                      className="bg-green-500 h-3 rounded-full transition-all duration-1000"
                      style={{ width: `${prediction.confidence * 100}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    Model is {(prediction.confidence * 100).toFixed(1)}% confident in this classification
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <AlertCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Upload an image to see classification results</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="section-card border-l-orange-500">
        <div className="flex items-center space-x-3 mb-6">
          <Brain className="h-6 w-6 text-orange-500" />
          <h3 className="text-xl font-semibold text-gray-800">Rice Type Reference</h3>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {riceTypes.map((rice, index) => (
            <div key={index} className="bg-orange-50 p-4 rounded-lg">
              <h4 className="font-semibold text-orange-800 mb-2">{rice.name}</h4>
              <p className="text-sm text-gray-600">{rice.characteristics}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="section-card border-l-purple-500">
        <div className="flex items-center space-x-3 mb-6">
          <CheckCircle className="h-6 w-6 text-purple-500" />
          <h3 className="text-xl font-semibold text-gray-800">Model Performance Metrics</h3>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">94.2%</div>
            <div className="text-sm text-gray-600">Overall Accuracy</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">92.8%</div>
            <div className="text-sm text-gray-600">Precision</div>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">91.5%</div>
            <div className="text-sm text-gray-600">Recall</div>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <div className="text-2xl font-bold text-orange-600">150ms</div>
            <div className="text-sm text-gray-600">Inference Time</div>
          </div>
        </div>
      </div>

      <div className="section-card border-l-indigo-500">
        <div className="flex items-center space-x-3 mb-6">
          <Brain className="h-6 w-6 text-indigo-500" />
          <h3 className="text-xl font-semibold text-gray-800">Application Features</h3>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-800">Core Capabilities</h4>
            <ul className="space-y-2">
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-gray-600">Real-time image classification</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-gray-600">Confidence score reporting</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-gray-600">Multiple image format support</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-gray-600">Batch processing capability</span>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-800">Technical Specifications</h4>
            <ul className="space-y-2">
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-blue-500" />
                <span className="text-gray-600">TensorFlow.js integration</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-blue-500" />
                <span className="text-gray-600">Client-side inference</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-blue-500" />
                <span className="text-gray-600">Responsive web design</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-blue-500" />
                <span className="text-gray-600">Progressive Web App ready</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicationDemo;