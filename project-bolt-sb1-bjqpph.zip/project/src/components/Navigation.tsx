import React from 'react';
import { Database, ImageIcon, Brain, Smartphone, Home } from 'lucide-react';

interface NavigationProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeSection, setActiveSection }) => {
  const sections = [
    { id: 'overview', label: 'Project Overview', icon: Home },
    { id: 'data', label: '1: Data Collection', icon: Database },
    { id: 'preprocessing', label: '2: Image Preprocessing', icon: ImageIcon },
    { id: 'model', label: '3: Model Building', icon: Brain },
    { id: 'application', label: '5: Application Demo', icon: Smartphone },
  ];

  return (
    <nav className="bg-white shadow-lg border-b-2 border-green-200">
      <div className="container mx-auto px-4">
        <div className="flex overflow-x-auto space-x-1 py-4">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg whitespace-nowrap transition-all duration-200 ${
                  activeSection === section.id
                    ? 'bg-green-500 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-green-100 hover:text-green-700'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="font-medium text-sm">{section.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};

export default Navigation;