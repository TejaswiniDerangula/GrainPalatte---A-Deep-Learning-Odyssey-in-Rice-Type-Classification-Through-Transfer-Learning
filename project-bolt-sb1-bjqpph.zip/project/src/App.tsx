import React, { useState } from 'react';
import Header from './components/Header';
import ProjectOverview from './components/ProjectOverview';
import DataCollection from './components/DataCollection';
import ImagePreprocessing from './components/ImagePreprocessing';
import ModelBuilding from './components/ModelBuilding';
import ApplicationDemo from './components/ApplicationDemo';
import Navigation from './components/Navigation';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState('overview');

  const renderSection = () => {
    switch (activeSection) {
      case 'overview':
        return <ProjectOverview />;
      case 'data':
        return <DataCollection />;
      case 'preprocessing':
        return <ImagePreprocessing />;
      case 'model':
        return <ModelBuilding />;
      case 'application':
        return <ApplicationDemo />;
      default:
        return <ProjectOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-orange-50">
      <Header />
      <Navigation activeSection={activeSection} setActiveSection={setActiveSection} />
      <main className="container mx-auto px-4 py-8">
        {renderSection()}
      </main>
    </div>
  );
};

export default App;